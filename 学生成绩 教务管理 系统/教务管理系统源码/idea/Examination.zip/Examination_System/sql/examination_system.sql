/*
Navicat MySQL Data Transfer

Source Server         : guting
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : examination_system

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2018-03-12 00:22:46
*/

SET FOREIGN_KEY_CHECKS=0;
